﻿using Z.EntityFramework.Plus;

namespace Z.Test.EntityFramework.Plus
{
    public class AuditEntryProperty_Extended : AuditEntryProperty
    {
        public string ExtendedValue { get; set; }
    }
}

﻿using Z.EntityFramework.Plus;

namespace Z.Test.EntityFramework.Plus
{
    public class AuditEntry_Extended : AuditEntry
    {
        public string ExtendedValue { get; set; }
    }
}

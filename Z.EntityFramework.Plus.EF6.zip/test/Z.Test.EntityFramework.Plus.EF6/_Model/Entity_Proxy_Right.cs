﻿namespace Z.Test.EntityFramework.Plus
{
    public class Entity_Proxy_Right
    {
        public int ID { get; set; }

        public int ColumnInt { get; set; }

        public Entity_Proxy Left { get; set; }
    }
}
﻿using System;

namespace Z.EntityFramework.Plus
{
    [AttributeUsage(AttributeTargets.All)]
    public class AuditIncludeAttribute : Attribute
    {
    }
}